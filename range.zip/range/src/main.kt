import org.w3c.dom.ranges.Range

fun main(args: Array<String>){
    var range: IntRange = 1..1000//not reverse range, always going from min to max
    for (item in range){
        println(item)
    }

    //if you want to go with a type then (item: Int in range)
 //   var range: IntRange = 1..1000
  //  for (item: Int in range){
  //      println(item)
  //  }

    //if you want to go in reverse (item: Int in reverseRange)
    //   var range: IntRange = 1..1000
    //   var reverseRange : IntProgression = 1000 downTo 1
    //  for (item: Int in reverseRange){
    //      println(item)
    //  }

    //if you want to go in stepProgression (item: Int in stepProgression)
    //   var range: IntRange = 1..1000
    //   var reverseRange : IntProgression = 1000 downTo 1
    //  var stepProgression: IntProgresion = 1..1000 step 5
    //  for (item: Int in stepProgression){
    //      println(item)
    //  }


    //if you want to go in untilProgression (item: Int in untilProgression)
    //   var range: IntRange = 1..1000
    //   var reverseRange : IntProgression = 1000 downTo 1
    //  var stepProgression: IntProgresion = 1..1000 step 5
    //  var untilProgression: IntProgresion = 1 until 1000 //[1, 1000] last not included
    //  for (item: Int in untilProgression){
    //      println(item)
    //  }

    //if you want to go in mixProgression (item: Int in untilProgression)
    //   var range: IntRange = 1..1000
    //   var reverseRange : IntProgression = 1000 downTo 1
    //  var stepProgression: IntProgresion = 1..1000 step 5
    //  var untilProgression: IntProgresion = 1 until 1000 //[1, 1000] last not included
    //  var mixProgression: IntProgresion = 1000 downTo 1 step 100
    //  for (item: Int in mixProgression){
    //      println(item)
    //  }
}