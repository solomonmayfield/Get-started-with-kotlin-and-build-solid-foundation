//four types of visibility modifiers

//Private Function

class Person{
    private var Name: String = ""
}
private fun abc(){


}





/*

class Person{
    private var Name: String = ""
}*/

/*//Private Function

class Person{
    private var Name: String = ""
}
private fun abc(){


}*/