/*
fun max(a: Int, b: Int): Int{
    var answer = if (a>b){//this whole block is an expression
        a
    }else if(a==b){
        b

    }else{
        b
    }
    return answer
}

fun main(args: Array<String>){

    var a: Int = 3
    var b: Int = 5
    var max: Int = max(a,b)
    println("The Max is : ${max}")
}


*/

/**
fun max(a: Int, b: Int): Int{
    var answer = if (a>b){//this whole block is an expression
        a
    }else if(a==b){
        b

    }else{
        b
    }
    return answer
}

fun printNumber(num: Int){
    when(num){
        0 -> println("Number is everything zero")
        1 -> println("Number is 1")
        else -> {
            println("Number is everything else")
        }
    }

}
fun main(args: Array<String>){

    var a: Int = 3//change value to 1
    printNumber(a)
}
 */
/**
fun max(a: Int, b: Int): Int{
var answer = if (a>b){//this whole block is an expression
a
}else if(a==b){
b

}else{
b
}
return answer
}

fun printNumber(num: Int){
        var answer = when(num){
            0 -> "Number is everything zero"
            1 -> "Number is 1"
            else -> {
            "Other"
        }

    }
   println("Number is ${answer}")

}
fun main(args: Array<String>){

var a: Int = 3
printNumber(a)
}
*/

/**
fun max(a: Int, b: Int): Int{
    var answer = if (a>b){//this whole block is an expression
        a
    }else if(a==b){
        b

    }else{
        b
    }
    return answer
}

fun printNumber(num: Int){
    var answer = when(num){
        in 0..10 -> "Between 1 to 10"
        in 11..1000 -> "Between 11 to 1000"
        else -> {
            "Other"
        }

    }
    println("Number is ${answer}")

}
fun main(args: Array<String>){

    var a: Int = 3
    printNumber(a)
}

*/


fun max(a: Int, b: Int): Int{
    var answer = if (a>b){//this whole block is an expression
        a
    }else if(a==b){
        b

    }else{
        b
    }
    return answer
}

fun printNumber(num: Int){
    var answer = when(num){
        getVal(num) -> "Between 1 to 10"
        in 11..1000 -> "Between 11 to 1000"
        else -> {
            "Other"
        }

    }
    println("Number is ${answer}")

}
fun main(args: Array<String>){

    var a: Int = 3
    printNumber(a)
}

fun getVal(value: Int) : Int{
    println("Called this function")
    return value
}