fun main(args: Array<String>) {
    var people: Array<String> = arrayOf<String>("A", "B", "C", "D")


    for (person: String in people) {
        println(people)
    }

}


fun main(args: Array<String>) {
    var people: Array<String> = arrayOf<String>("A", "B", "C", "D")
    var range: IntRange = 1..10

    for (item: Int in range) {
        println(item)
    }

}

fun main(args: Array<String>) {

    var cond: Int = 0

    while (cond < 10) {//while condition is LESS

        println(cond)
        cond++

    }

}

fun main(args: Array<String>) {

    var cond: Int = 0

    do {//while condition is LESS

        println(cond)
        cond++

    }while (true)

}


fun main(args: Array<String>) {

    var cond: Int = 0

    repeat(10) {//while condition is LESS

        println(cond)
        cond++

    }

}

fun main(args: Array<String>) {

    var cond: Int = 0

    repeat(10) {//while condition is LESS

        println(cond)
        cond++

    }

}