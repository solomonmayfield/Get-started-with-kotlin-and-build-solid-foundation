/*fun main(args: Array<String>) {
    var firstLambda: (Int, Int)/*takes two parameters as input*/ -> Int = { a: Int, b: Int ->
        a + b
    }

    var result = firstLambda(2, 3)
    println("The lambda result is ${result}")
}
*/
/*
//closure functions
fun main(args: Array<String>) {
    var counter: Int = 0
    var firstLambda: (Int, Int)/*takes two parameters as input*/ -> Int = {
            a: Int, b: Int ->
        counter++
        a + b
    }

    var result = firstLambda(2, 3)
    println("The lambda result is ${result}")
    println("The count result is ${counter}")
}
*/

/*
//loop functions
fun main(args: Array<String>) {
    var items: Array<Int> = arrayOf<Int>(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    var lambda: (Int) -> Int = { item: Int ->
        item + item
    }
    var doubled: Array<Int> = Loop(items, { item: Int ->
        item + item
    })
    for (newItem in items) {
        println("Doubled items ${newItem}")
    }
}

fun Loop(items: Array<Int>, cl: (a: Int) -> Int): Array<Int> {
    var newItems: Array<Int> = items
    var index: Int = 0
    for (item in items) {
        var transformed: Int = cl(item)
        newItems.set(index, transformed)
        index++
    }
    return newItems
}

*/
/*
//anonymous functions
fun main(args: Array<String>) {

    var f = fun (a:Int,b: Int) : Int {
        return 0
    }


}
*/
/*
//High Order functions
fun main(args: Array<String>) {
    var items: Array<Int> = arrayOf<Int>(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    var lambda: (Int) -> Int = { item: Int ->
        item + item
    }
    var doubled: Array<Int> = Loop(items, { item: Int ->
        item + item
    })
    for (newItem in items) {
        println("Doubled items ${newItem}")
    }
}

fun Loop(items: Array<Int>, cl: (a: Int) -> Int): Array<Int> {
    var newItems: Array<Int> = items
    var index: Int = 0
    for (item in items) {
        var transformed: Int = cl(item)
        newItems.set(index, transformed)
        index++
    }
    return newItems
}

*/

//Inline functions
fun main(args: Array<String>) {
    var items: Array<Int> = arrayOf<Int>(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    var doubled: Array<Int> = Loop(items, { item: Int ->
        item + item
    })
    for (newItem in items) {
        println("Doubled items ${doubled}")
    }
}

inline fun Loop(items: Array<Int>, cl: (a: Int) -> Int): Array<Int> {
    var newItems: Array<Int> = items
    var index: Int = 0
    for (item in items) {
        var transformed: Int = cl(item)
        newItems.set(index, transformed)
        index++
    }
    return newItems
}