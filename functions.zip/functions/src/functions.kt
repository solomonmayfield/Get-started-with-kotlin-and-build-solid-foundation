/**
fun main(args: Array<String>){

    NameOfFun("SM")




}
fun NameOfFun(name: String): Unit {

    println("Hello World.")

}

//Function Parameters
fun main(args: Array<String>){

    NameOfFun("SM", age = 26)




}
fun NameOfFun(name: String, age: Int): Unit {

    println("The age of ${name} is ${age}")

}
*/
/*

//Function IsAllowed
fun main(args: Array<String>){

    var isAllowed: Boolean = IsAllowed("SM", 26)

    println("is Allowed ? ${isAllowed}")


}
fun IsAllowed(name: String, age: Int): Boolean {

    if (age < 21) {

        return false
    }else{
return true
    }
}
*/
/*
//Function IsAllowed
fun main(args: Array<String>){

    var isAllowed: Boolean = IsAllowed("SM")

    println("is Allowed ? ${isAllowed}")


}
fun IsAllowed(name: String, age: Int = 10): Boolean {

    if (age < 21) {

        return false
    }else{
        return true
    }
}
*/

/**
//Named Parameter feature in kotlin
fun main(args: Array<String>){

    var isAllowed: Boolean = IsAllowed(name = "SM", age = 30)

    println("is Allowed ? ${isAllowed}")


}
fun IsAllowed( age: Int = 10,name: String): Boolean {

    if (age < 21) {

        return false
    }else{
        return true
    }
}
*/

//Variable Arguments
fun main(args: Array<String>){

//GetNames("SM")
    GetNames("SM","JP","AJ")


}
fun GetNames(vararg names: String): Unit {

    for (name in names){
        println("The name is ${name}")
    }

}