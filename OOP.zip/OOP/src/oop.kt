

//Pass as a TYPE
class Student {
    annotation class Inject

    init {//Initializing values to properties
        println("First Init called")
       // FirstName = firstName //wont work everythings in order
    }


    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte) {
       println("Secodary cons called")
        FirstName = firstName
        LastName = lastName
        Age = age

    }

    fun PrintStudent(){
        println("FirstName: ${this.FirstName}" +
                "LastName: ${this.LastName}" +
                "Age: ${this.Age}" )
    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1: Student = Student("SM", "Bambhaniya", 26)
    student1.PrintStudent()

}






/*
//Initialize
class Student constructor(firstName: String, lastName: String) {
    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Init called")
        FirstName = firstName
        LastName = LastName
    }
}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya")
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}")

}
*/
/*
//Second Initialize
class Student constructor(firstName: String, lastName: String) {
    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Init called")
        FirstName = firstName
        LastName = LastName
    }
    init {//Initializing values to properties
        println("Second Init called")

    }
}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya")
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}")

}
*/
/*
//Initialize
class Student constructor(firstName: String, lastName: String) {

    init {//Initializing values to properties
        println("First Init called")
        // FirstName = firstName //wont work everythings in order
    }

    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")
        FirstName = firstName
        LastName = LastName
    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya")
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}")

}

*/


/*
class Student(firstName: String, lastName: String) {
    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890
}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya")
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}")

}
*/
/**
//Secondary Constructor
class Student constructor(var firstName: String = "",var lastName: String="") {

    init {//Initializing values to properties
        println("First Init called")
        // FirstName = firstName //wont work everythings in order
    }


    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte): this(firstName,lastName){
        println("Secodary cons called")
        Age = age

    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya", 26)
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}" + "The age is : ${student1.Age}")

}

*/
/**
//Visibility Modifiers
class Student private @Inject constructor(var firstName: String = "",var lastName: String="") {
    annotation class Inject

    init {//Initializing values to properties
        println("First Init called")
        // FirstName = firstName //wont work everythings in order
    }


    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte): this(firstName,lastName){
        println("Secodary cons called")
        Age = age

    }

}
*/

/*
* //This will work as well
class Student(var firstName: String = "",var lastName: String="") {
    annotation class Inject

    init {//Initializing values to properties
        println("First Init called")
       // FirstName = firstName //wont work everythings in order
    }


    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte): this(firstName,lastName){
       println("Secodary cons called")
        Age = age

    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya", 26)
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}" + "The age is : ${student1.Age}")

}
*
*
*
* */


/*
*
//No Primary Constructor
class Student {
    annotation class Inject

    init {//Initializing values to properties
        println("First Init called")
       // FirstName = firstName //wont work everythings in order
    }


    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte) {
       println("Secodary cons called")
        FirstName = firstName
        LastName = lastName
        Age = age

    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya", 26)
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}" + "The age is : ${student1.Age}")

}
*
* */


/*
*
*

//Can not define properties with out Primary Constructor
class Student {
    annotation class Inject

    init {//Initializing values to properties
        println("First Init called")
       // FirstName = firstName //wont work everythings in order
    }


    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte) {
       println("Secodary cons called")
        FirstName = firstName
        LastName = lastName
        Age = age

    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya", 26)
    println("The first name of the student is${student1.FirstName}, last name is ${student1.LastName}" + "The age is : ${student1.Age}")

}
*
*
* */


/*
*

//Member Functions
class Student {
    annotation class Inject

    init {//Initializing values to properties
        println("First Init called")
       // FirstName = firstName //wont work everythings in order
    }


    var FirstName: String = ""
    var LastName: String = ""
    var Age: Byte = 0
    var Address: String = ""
    var EnrollNo: Long = 1234567890

    init {//Initializing values to properties
        println("Second Init called")

    }

    constructor(firstName: String, lastName: String,age: Byte) {
       println("Secodary cons called")
        FirstName = firstName
        LastName = lastName
        Age = age

    }

    fun PrintStudent(){
        println("FirstName: ${this.FirstName}" +
                "LastName: ${this.LastName}" +
                "Age: ${this.Age}" )
    }

}

//class Empty//class without body

//Constructors
/*Constructors
A class in Kotlin can have a primary constructor and one or more secondary constructors.
The primary constructor is part of the class header :
    it goes after the class name(and optional type parameters).
*/
fun main(args: Array<String>) {
    var student1 = Student("SM", "Bambhaniya", 26)
    student1.PrintStudent()

}
*
*
* */