

class bajajBulb : Bulb{


    override fun on(){
        println("Bulb is on")
    }
    override fun off(){
        println("Bulb is off")
    }
}


class PhillipsBulb : Bulb {


    //override fun on(){
      //  println("Bulb is on")
    //}
    override fun off(){
        println("PhillipsBulb is off")
    }
}

//
interface Bulb{
    fun on(){
        println("This is the default method...")
    }
    fun off()



}
class Switch {

    fun turn_off(bulb: Bulb) {

        bulb.off()
    }

    fun turn_on(bulb: Bulb) {
        bulb.on()
    }

}

fun main(args: Array<String>){
    val bb: Bulb = bajajBulb()
    val pb: Bulb = PhillipsBulb()

    var switch: Switch = Switch()
    switch.turn_on(bb)
    switch.turn_on(pb)

}


/*
* class Bulb{


    fun on(){
        println("Bulb is on")
    }
    fun off(){
        println("Bulb is off")
    }
}

class Switch {




    fun turn_off(bulb: Bulb) {

        bulb.off()
    }

    fun turn_on(bulb: Bulb) {
        bulb.on()
    }
}

fun main(args: Array<String>){
    val bb: Bulb = Bulb()
    var switch: Switch = Switch()
    switch.turn_on(bb)
}*/


/*class Bulb{


    fun on(){
        println("Bulb is on")
    }
    fun off(){
        println("Bulb is off")
    }
}


class PhillipsBulb{


    fun on(){
        println("Bulb is on")
    }
    fun off(){
        println("PhillipsBulb is off")
    }
}

class Switch {




    fun turn_off(bulb: Bulb) {

        bulb.off()
    }

    fun turn_on(bulb: Bulb) {
        bulb.on()
    }
    fun turn_offp(bulb: PhillipsBulb) {

        bulb.off()
    }

    fun turn_onp(bulb: PhillipsBulb) {
        bulb.on()
    }
}

fun main(args: Array<String>){
    val bb: Bulb = Bulb()
    var switch: Switch = Switch()

    val pb: PhillipsBulb = PhillipsBulb()


    switch.turn_on(bb)
    switch.turn_onp(pb)
}
*/


/*
class bajajBulb : Bulb{


    override fun on(){
        println("Bulb is on")
    }
    override fun off(){
        println("Bulb is off")
    }
}


class PhillipsBulb{


    fun on(){
        println("Bulb is on")
    }
    fun off(){
        println("PhillipsBulb is off")
    }
}

//
interface Bulb{
    fun on()
    fun off()



}
class Switch {

    fun turn_off(bulb: Bulb) {

        bulb.off()
    }

    fun turn_on(bulb: Bulb) {
        bulb.on()
    }

}

fun main(args: Array<String>){
    val bb: Bulb = bajajBulb()
    var switch: Switch = Switch()

    val pb: PhillipsBulb = PhillipsBulb()


    switch.turn_on(bb)

}

*/

/*//PhillipsBulb did not turn on resulted to interface default on method
class bajajBulb : Bulb{


    override fun on(){
        println("Bulb is on")
    }
    override fun off(){
        println("Bulb is off")
    }
}


class PhillipsBulb : Bulb {


    //override fun on(){
      //  println("Bulb is on")
    //}
    override fun off(){
        println("PhillipsBulb is off")
    }
}

//
interface Bulb{
    fun on(){
        println("This is the default method...")
    }
    fun off()



}
class Switch {

    fun turn_off(bulb: Bulb) {

        bulb.off()
    }

    fun turn_on(bulb: Bulb) {
        bulb.on()
    }

}

fun main(args: Array<String>){
    val bb: Bulb = bajajBulb()
    val pb: Bulb = PhillipsBulb()

    var switch: Switch = Switch()
    switch.turn_on(bb)
    switch.turn_on(pb)

}*/