
//Override Variable - open by default to stop that write final key
open class Person constructor(name: String, age: Int) {
   open var Name: String = ""//1. Open keyword
    var Age: Int = 0
    var ID: Int = 0

    init {
        Name = name
        Age = age

    }

    constructor(name: String, age: Int, id: Int) : this(name, age) {
        ID = id
    }


    open fun PrintPerson() {
        println(
            "Name: ${this.Name}\n" +
                    "Age: ${this.Age}\n" +
                    "ID: ${this.Name}\n"
        )
    }

}

class Student : Person {

    //When you have secondary key word use super keyword to do all kinds of thing
    constructor(name: String, age: Int, id: Int) : super(name, age, id)

    override var Name: String = ""//Override Keyword - Inheritance
    //final override var Name: String = ""//final override Keyword - Inheritance
    //open by default to stop that write final key
    final override fun PrintPerson() {
        super.PrintPerson()
        println(
            "Type: STUDENT\n" +
            "Name: ${this.Name}\n" +
            "Age: ${this.Age}\n" +
            "ID: ${this.ID}\n"

        )
    }
}

fun main(args: Array<String>) {
    var s1 = Student(name = "SM", age = 26, id = 22)
    s1.PrintPerson()
}


/*Inherite from parent
* open class Person constructor(name: String, age: Int){
    var Name: String = ""
    var Age: Int = 0
    var ID: Int = 0

    init {
        Name = name
        Age = age

    }

    constructor(name: String, age: Int, id: Int): this(name,age){
        ID = id
    }


    fun PrintPerson(){
        println("Name: ${this.Name}" +
                "Age: ${this.Age}" +
                "ID: ${this.Name}")
    }

}

class Student (name: String,age: Int,id: Int) : Person(name,age){
    init {
        ID = id
    }
}

fun main(args: Array<String>){
    var s1 = Student(name = "SM", age = 26, id = 22)
    s1.PrintPerson()
}
*
*
*
* */


/*
* open class Person constructor(name: String, age: Int){
    var Name: String = ""
    var Age: Int = 0
    var ID: Int = 0

    init {
        Name = name
        Age = age

    }

    constructor(name: String, age: Int, id: Int): this(name,age){
        ID = id
    }


    fun PrintPerson(){
        println("Name: ${this.Name}" +
                "Age: ${this.Age}" +
                "ID: ${this.Name}")
    }

}

class Student : Person{

    //When you have secondary key word use super keyword to do all kinds of thing
    constructor(name: String,age: Int, id: Int): super(name,age,id)

}

fun main(args: Array<String>){
    var s1 = Student(name = "SM", age = 26, id = 22)
    s1.PrintPerson()
}
*
* */


/**
 * //Override Function
open class Person constructor(name: String, age: Int) {
var Name: String = ""
var Age: Int = 0
var ID: Int = 0

init {
Name = name
Age = age

}

constructor(name: String, age: Int, id: Int) : this(name, age) {
ID = id
}


open fun PrintPerson() {
println(
"Name: ${this.Name}\n" +
"Age: ${this.Age}\n" +
"ID: ${this.Name}\n"
)
}

}

class Student : Person {

//When you have secondary key word use super keyword to do all kinds of thing
constructor(name: String, age: Int, id: Int) : super(name, age, id)

//When you override a method you have to use override key word
override fun PrintPerson() {
super.PrintPerson()
println(
"Type: STUDENT\n" +
"Name: ${this.Name}\n" +
"Age: ${this.Age}\n" +
"ID: ${this.ID}\n"

)
}
}

fun main(args: Array<String>) {
var s1 = Student(name = "SM", age = 26, id = 22)
s1.PrintPerson()
}


 * */

/*//Override Function - open by default to stop that write final key
open class Person constructor(name: String, age: Int) {
    var Name: String = ""
    var Age: Int = 0
    var ID: Int = 0

    init {
        Name = name
        Age = age

    }

    constructor(name: String, age: Int, id: Int) : this(name, age) {
        ID = id
    }


    open fun PrintPerson() {
        println(
            "Name: ${this.Name}\n" +
                    "Age: ${this.Age}\n" +
                    "ID: ${this.Name}\n"
        )
    }

}

class Student : Person {

    //When you have secondary key word use super keyword to do all kinds of thing
    constructor(name: String, age: Int, id: Int) : super(name, age, id)

    //open by default to stop that write final key
    final override fun PrintPerson() {
        super.PrintPerson()
        println(
            "Type: STUDENT\n" +
            "Name: ${this.Name}\n" +
            "Age: ${this.Age}\n" +
            "ID: ${this.ID}\n"

        )
    }
}

fun main(args: Array<String>) {
    var s1 = Student(name = "SM", age = 26, id = 22)
    s1.PrintPerson()
}

 */
